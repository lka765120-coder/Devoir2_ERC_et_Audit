// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title CertificateRegistry - registre de certificats academiques on-chain
/// @notice Seuls l'owner et les admins autorises peuvent emettre ou revoquer.
contract CertificateRegistry {
    struct Certificate {
        string studentName;
        string studentId;
        string diplomaTitle;
        string issueDate;
        string grade;
        address recipient;
        bool revoked;
    }

    address public owner;
    mapping(address => bool) public admins;

    uint256 public totalCertificates;
    uint256 public constant MAX_BATCH = 50; // garde-fou gas

    mapping(uint256 => Certificate) private _certs;
    // hash(studentId, diplomaTitle) => certId (0 = pas encore emis)
    mapping(bytes32 => uint256) private _certIdByKey;

    event CertificateMinted(
        uint256 indexed certId,
        address indexed recipient,
        string studentId,
        string diplomaTitle
    );
    event CertificateRevoked(uint256 indexed certId);
    event AdminUpdated(address indexed admin, bool allowed);

    modifier onlyOwner() {
        require(msg.sender == owner, "Reserve a l'owner");
        _;
    }

    modifier onlyAdmin() {
        require(msg.sender == owner || admins[msg.sender], "Non autorise");
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    // ---------- Gestion des admins ----------

    function setAdmin(address admin, bool allowed) external onlyOwner {
        admins[admin] = allowed;
        emit AdminUpdated(admin, allowed);
    }

    // ---------- Ecriture ----------

    function mintCertificate(
        address to,
        string calldata studentName,
        string calldata studentId,
        string calldata diplomaTitle,
        string calldata issueDate,
        string calldata grade
    ) external onlyAdmin returns (uint256 certId) {
        certId = _issue(to, studentName, studentId, diplomaTitle, issueDate, grade);
    }

    function batchMint(
        address[] calldata recipients,
        string[] calldata studentNames,
        string[] calldata studentIds,
        string[] calldata diplomaTitles,
        string[] calldata issueDates,
        string[] calldata grades
    ) external onlyAdmin {
        uint256 n = recipients.length;
        require(n > 0 && n <= MAX_BATCH, "Taille de lot invalide");
        require(
            studentNames.length == n &&
                studentIds.length == n &&
                diplomaTitles.length == n &&
                issueDates.length == n &&
                grades.length == n,
            "Tableaux de tailles differentes"
        );
        for (uint256 i = 0; i < n; i++) {
            _issue(recipients[i], studentNames[i], studentIds[i], diplomaTitles[i], issueDates[i], grades[i]);
        }
    }

    function revoke(uint256 certId) external onlyAdmin {
        require(_exists(certId), "Certificat inexistant");
        require(!_certs[certId].revoked, "Deja revoque");
        _certs[certId].revoked = true;
        emit CertificateRevoked(certId);
    }

    // ---------- Lecture (gratuite : view) ----------

    function getCertificate(uint256 certId) external view returns (Certificate memory) {
        require(_exists(certId), "Certificat inexistant");
        return _certs[certId];
    }

    /// @return certId (0 si aucun certificat pour ce couple etudiant/diplome)
    function findCertId(string calldata studentId, string calldata diplomaTitle) external view returns (uint256) {
        return _certIdByKey[keccak256(abi.encode(studentId, diplomaTitle))];
    }

    // ---------- Interne ----------

    function _exists(uint256 certId) internal view returns (bool) {
        return certId > 0 && certId <= totalCertificates;
    }

    function _issue(
        address to,
        string calldata studentName,
        string calldata studentId,
        string calldata diplomaTitle,
        string calldata issueDate,
        string calldata grade
    ) internal returns (uint256 certId) {
        require(
            bytes(studentName).length > 0 && bytes(studentId).length > 0 && bytes(diplomaTitle).length > 0,
            "Champs obligatoires vides"
        );
        // Anti-doublon : un meme etudiant peut avoir plusieurs diplomes differents,
        // mais pas deux fois le meme diplome.
        bytes32 key = keccak256(abi.encode(studentId, diplomaTitle));
        require(_certIdByKey[key] == 0, "Certificat deja emis (doublon)");

        certId = ++totalCertificates; // les ids commencent a 1
        _certIdByKey[key] = certId;
        _certs[certId] = Certificate(studentName, studentId, diplomaTitle, issueDate, grade, to, false);

        emit CertificateMinted(certId, to, studentId, diplomaTitle);
    }
}
