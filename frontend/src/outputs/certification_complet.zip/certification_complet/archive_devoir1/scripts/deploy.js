const fs = require("fs");
const path = require("path");
const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploiement avec :", deployer.address);

  const registry = await (await hre.ethers.getContractFactory("CertificateRegistry")).deploy();
  await registry.waitForDeployment();
  const address = await registry.getAddress();
  console.log("CertificateRegistry deploye a :", address);

  // Le frontend lit ce fichier : adresse + ABI + chainId
  const artifact = await hre.artifacts.readArtifact("CertificateRegistry");
  const { chainId } = await hre.ethers.provider.getNetwork();
  const out = { address, chainId: Number(chainId), abi: artifact.abi };
  fs.writeFileSync(path.join(__dirname, "../frontend/src/contract.json"), JSON.stringify(out, null, 2));
  console.log("frontend/src/contract.json mis a jour");
}

main().catch((e) => { console.error(e); process.exitCode = 1; });
