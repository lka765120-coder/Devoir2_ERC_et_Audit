const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("CertificateRegistry", () => {
  let registry, owner, admin, other;
  const Z = ethers.ZeroAddress;

  beforeEach(async () => {
    [owner, admin, other] = await ethers.getSigners();
    registry = await (await ethers.getContractFactory("CertificateRegistry")).deploy();
  });

  const mint = (c = registry, id = "2023-INF-042") =>
    c.mintCertificate(other.address, "Amina Benali", id, "Licence Informatique", "2026-06-15", "Bien");

  it("l'owner peut emettre et l'event est emis", async () => {
    await expect(mint()).to.emit(registry, "CertificateMinted").withArgs(1, other.address, "2023-INF-042", "Licence Informatique");
    const c = await registry.getCertificate(1);
    expect(c.studentName).to.equal("Amina Benali");
    expect(c.revoked).to.equal(false);
  });

  it("refuse un compte non autorise, accepte un admin", async () => {
    await expect(mint(registry.connect(admin))).to.be.revertedWith("Non autorise");
    await registry.setAdmin(admin.address, true);
    await expect(mint(registry.connect(admin))).to.emit(registry, "CertificateMinted");
  });

  it("seul l'owner gere les admins", async () => {
    await expect(registry.connect(other).setAdmin(other.address, true)).to.be.revertedWith("Reserve a l'owner");
  });

  it("refuse le doublon etudiant + diplome", async () => {
    await mint();
    await expect(mint()).to.be.revertedWith("Certificat deja emis (doublon)");
  });

  it("refuse les champs obligatoires vides", async () => {
    await expect(registry.mintCertificate(Z, "", "X", "Y", "2026-01-01", "")).to.be.revertedWith("Champs obligatoires vides");
  });

  it("batchMint cree plusieurs certificats", async () => {
    await registry.batchMint(
      [Z, Z], ["A", "B"], ["1", "2"], ["Licence", "Licence"], ["2026-06-15", "2026-06-15"], ["Bien", "TB"]
    );
    expect(await registry.totalCertificates()).to.equal(2);
    expect((await registry.getCertificate(2)).studentName).to.equal("B");
  });

  it("batchMint refuse des tableaux de tailles differentes", async () => {
    await expect(
      registry.batchMint([Z], ["A", "B"], ["1"], ["L"], ["d"], ["g"])
    ).to.be.revertedWith("Tableaux de tailles differentes");
  });

  it("revoke marque le certificat comme revoque", async () => {
    await mint();
    await expect(registry.revoke(1)).to.emit(registry, "CertificateRevoked").withArgs(1);
    expect((await registry.getCertificate(1)).revoked).to.equal(true);
    await expect(registry.revoke(1)).to.be.revertedWith("Deja revoque");
  });

  it("getCertificate revert si l'id n'existe pas", async () => {
    await expect(registry.getCertificate(99)).to.be.revertedWith("Certificat inexistant");
  });
});
